import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

// This API route ACTUALLY analyzes video frames using VLM (Vision Language Model)
// It validates whether the video is a genuine resume/interview video
// and ONLY returns analysis if it's valid

function extractJSON(text: string): Record<string, unknown> | null {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    return jsonMatch ? JSON.parse(jsonMatch[0]) : null
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { frames, profile } = body as {
      frames: string[] // base64 encoded video frames
      profile: { name: string; role: string; skills: string[]; experience: string; bio: string }
    }

    if (!frames || frames.length === 0) {
      return NextResponse.json(
        { success: false, error: 'No video frames provided. Please upload a valid video file.' },
        { status: 400 }
      )
    }

    // Use only up to 3 frames to stay within API limits
    const framesToAnalyze = frames.slice(0, 3)

    const zai = await ZAI.create()

    // Step 1: VALIDATE — Is this a video resume/interview?
    const validationMessages = [
      {
        role: 'system' as const,
        content: 'You are an AI that validates video resumes. You must determine if the provided video frames show a person presenting themselves professionally (like a video resume, job interview, or professional introduction). Be strict — a music video, gameplay, nature video, cartoon, empty/blank video, or any non-personal-presentation content should be rejected. You must respond with valid JSON only, no markdown.',
      },
      {
        role: 'user' as const,
        content: [
          {
            type: 'text' as const,
            text: 'Analyze these video frames from an uploaded file. Is this a video resume or professional introduction where a person is presenting themselves? Respond with JSON: { "isValidResume": boolean, "reason": "explanation of why it is or isn\'t valid", "detectedContent": "what you actually see in the video" }',
          },
          ...framesToAnalyze.map(
            (frame) =>
              ({
                type: 'image_url' as const,
                image_url: { url: frame.startsWith('data:') ? frame : `data:image/jpeg;base64,${frame}` },
              }) as const
          ),
        ],
      },
    ]

    let validationResult: { isValidResume: boolean; reason: string; detectedContent: string } | null = null

    try {
      // Use createVision so the model can actually SEE the video frames
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const validationResponse = await zai.chat.completions.createVision({
        messages: validationMessages as any,
        temperature: 0.3,
        thinking: { type: 'disabled' },
      })

      const validationText = validationResponse.choices?.[0]?.message?.content || ''
      const parsed = extractJSON(validationText)
      if (parsed && typeof parsed.isValidResume === 'boolean') {
        validationResult = {
          isValidResume: parsed.isValidResume as boolean,
          reason: (parsed.reason as string) || 'Unknown reason',
          detectedContent: (parsed.detectedContent as string) || 'Content not identified',
        }
      }
    } catch (error) {
      console.error('Validation VLM error:', error)
    }

    // If validation failed or determined it's NOT a resume video
    if (!validationResult) {
      return NextResponse.json({
        success: false,
        error: 'Unable to validate video content. The AI vision service may be temporarily unavailable. Please try again.',
        errorType: 'VALIDATION_UNAVAILABLE',
      })
    }

    if (!validationResult.isValidResume) {
      return NextResponse.json({
        success: false,
        error: `This doesn't appear to be a video resume. Detected: ${validationResult.detectedContent}. ${validationResult.reason}. Please upload a video where you are presenting yourself professionally, speaking to the camera about your experience and skills.`,
        errorType: 'INVALID_VIDEO',
        detectedContent: validationResult.detectedContent,
      })
    }

    // Step 2: ANALYZE — The video IS a valid resume. Now analyze it deeply.
    const analysisMessages = [
      {
        role: 'system' as const,
        content: `You are an expert AI human intelligence analyst specializing in video resume analysis. You analyze candidates' video presentations to assess their professional potential. You must be objective, thorough, and honest. Base your scores ONLY on what you can actually observe in the video. If you cannot determine something clearly, give a moderate score rather than guessing high. Return ONLY valid JSON, no markdown or code blocks.`,
      },
      {
        role: 'user' as const,
        content: [
          {
            type: 'text' as const,
            text: `Analyze this video resume in detail. The candidate's profile:
- Name: ${profile?.name || 'Unknown'}
- Role: ${profile?.role || 'Not specified'}
- Skills: ${profile?.skills?.join(', ') || 'Not listed'}
- Experience: ${profile?.experience || 'Not specified'}
- Bio: ${profile?.bio || 'Not provided'}

Based on what you can ACTUALLY SEE in the video frames (the person's demeanor, presentation style, professionalism, body language, etc.), provide a thorough analysis. Be honest — if the person seems nervous, score confidence lower. If they speak clearly, score speech clarity higher. Scores should reflect GENUINE observations, not generic compliments.

Return ONLY valid JSON with this exact structure:
{
  "isValidResume": true,
  "overallScore": <number 30-98>,
  "speechClarity": <number 25-98>,
  "confidence": <number 20-98>,
  "communication": <number 25-98>,
  "enthusiasm": <number 20-98>,
  "leadership": <number 15-98>,
  "eyeContact": <number 20-98>,
  "emotionalConsistency": <number 25-98>,
  "adaptability": <number 25-98>,
  "personalityInsights": [
    {"title": "<specific insight based on observation>", "description": "<2-3 sentence detailed explanation>", "score": <number 30-98>},
    {"title": "<specific insight based on observation>", "description": "<2-3 sentence detailed explanation>", "score": <number 30-98>},
    {"title": "<specific insight based on observation>", "description": "<2-3 sentence detailed explanation>", "score": <number 30-98>},
    {"title": "<specific insight based on observation>", "description": "<2-3 sentence detailed explanation>", "score": <number 30-98>}
  ],
  "personalitySummary": "<3-4 sentence honest assessment of this person's professional presentation>",
  "communicationStyle": "<specific communication style observed>",
  "primaryTrait": "<dominant personality trait observed>",
  "strengths": ["<observed strength 1>", "<observed strength 2>", "<observed strength 3>"],
  "areasForImprovement": ["<observed area 1>", "<observed area 2>"]
}`,
          },
          ...framesToAnalyze.map(
            (frame) =>
              ({
                type: 'image_url' as const,
                image_url: { url: frame.startsWith('data:') ? frame : `data:image/jpeg;base64,${frame}` },
              }) as const
          ),
        ],
      },
    ]

    try {
      // Use createVision so the model can actually SEE the video frames
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const analysisResponse = await zai.chat.completions.createVision({
        messages: analysisMessages as any,
        temperature: 0.5,
        thinking: { type: 'disabled' },
      })

      const analysisText = analysisResponse.choices?.[0]?.message?.content || ''
      const analysis = extractJSON(analysisText)

      if (analysis && typeof analysis.overallScore === 'number') {
        const clamp = (val: unknown, min: number, max: number) =>
          Math.min(max, Math.max(min, typeof val === 'number' ? val : min))

        const result = {
          isValidResume: true,
          overallScore: clamp(analysis.overallScore, 20, 98),
          speechClarity: clamp(analysis.speechClarity, 20, 98),
          confidence: clamp(analysis.confidence, 15, 98),
          communication: clamp(analysis.communication, 20, 98),
          enthusiasm: clamp(analysis.enthusiasm, 15, 98),
          leadership: clamp(analysis.leadership, 10, 98),
          eyeContact: clamp(analysis.eyeContact, 15, 98),
          emotionalConsistency: clamp(analysis.emotionalConsistency, 20, 98),
          adaptability: clamp(analysis.adaptability, 20, 98),
          personalityInsights: Array.isArray(analysis.personalityInsights)
            ? analysis.personalityInsights.slice(0, 4).map((insight: Record<string, unknown>) => ({
                title: String(insight.title || 'Observation'),
                description: String(insight.description || 'Based on video analysis'),
                score: clamp(insight.score, 20, 98),
              }))
            : [],
          personalitySummary: String(
            analysis.personalitySummary || 'Analysis completed based on video observation.'
          ),
          communicationStyle: String(analysis.communicationStyle || 'Professional'),
          primaryTrait: String(analysis.primaryTrait || 'Analytical'),
          strengths: Array.isArray(analysis.strengths)
            ? analysis.strengths.slice(0, 5).map(String)
            : [],
          areasForImprovement: Array.isArray(analysis.areasForImprovement)
            ? analysis.areasForImprovement.slice(0, 3).map(String)
            : [],
        }

        return NextResponse.json({ success: true, analysis: result })
      }
    } catch (error) {
      console.error('Analysis VLM error:', error)
    }

    return NextResponse.json({
      success: false,
      error: 'Video was recognized as a valid resume, but the AI analysis failed to generate results. Please try again.',
      errorType: 'ANALYSIS_FAILED',
    })
  } catch (error) {
    console.error('Video analysis API error:', error)
    return NextResponse.json(
      { success: false, error: 'Video analysis request failed. Please try again.' },
      { status: 500 }
    )
  }
}
