import { create } from 'zustand'

export interface UserProfile {
  name: string
  email: string
  role: string
  location: string
  bio: string
  skills: string[]
  experience: string
  avatarUrl: string | null
  isComplete: boolean
}

export interface AnalysisResults {
  overallScore: number | null
  speechClarity: number | null
  confidence: number | null
  communication: number | null
  enthusiasm: number | null
  leadership: number | null
  eyeContact: number | null
  emotionalConsistency: number | null
  adaptability: number | null
  personalityDimensions: {
    leadership: number
    confidence: number
    creativity: number
    emotionalIntelligence: number
    adaptability: number
    collaboration: number
    pressureHandling: number
  } | null
  careerPredictions: Array<{
    title: string
    match: number
    description: string
    strengths: string[]
  }> | null
  personalityInsights: Array<{
    title: string
    description: string
    score: number
  }> | null
  personalitySummary: string | null
  communicationStyle: string | null
  primaryTrait: string | null
  videoUploaded: boolean
  interviewCompleted: boolean
  interviewMessages: Array<{ role: 'ai' | 'user'; text: string }>
}

export interface SessionRecord {
  id: string
  date: string
  profileName: string
  profileRole: string
  overallScore: number | null
  profile: UserProfile
  analysis: AnalysisResults
}

interface UserState {
  profile: UserProfile
  analysis: AnalysisResults
  currentSection: string
  sessions: SessionRecord[]
  setProfile: (profile: Partial<UserProfile>) => void
  setAnalysis: (analysis: Partial<AnalysisResults>) => void
  setCurrentSection: (section: string) => void
  resetAnalysis: () => void
  hasProfile: () => boolean
  hasAnalysis: () => boolean
  resetSession: () => void
  saveCurrentSession: () => void
  loadSession: (id: string) => void
  deleteSession: (id: string) => void
}

const defaultProfile: UserProfile = {
  name: '',
  email: '',
  role: '',
  location: '',
  bio: '',
  skills: [],
  experience: '',
  avatarUrl: null,
  isComplete: false,
}

const defaultAnalysis: AnalysisResults = {
  overallScore: null,
  speechClarity: null,
  confidence: null,
  communication: null,
  enthusiasm: null,
  leadership: null,
  eyeContact: null,
  emotionalConsistency: null,
  adaptability: null,
  personalityDimensions: null,
  careerPredictions: null,
  personalityInsights: null,
  personalitySummary: null,
  communicationStyle: null,
  primaryTrait: null,
  videoUploaded: false,
  interviewCompleted: false,
  interviewMessages: [],
}

// Load saved sessions from localStorage (history only, not current session)
function loadSessions(): SessionRecord[] {
  if (typeof window === 'undefined') return []
  try {
    const saved = localStorage.getItem('neuralhire-sessions')
    return saved ? JSON.parse(saved) : []
  } catch {
    return []
  }
}

function saveSessions(sessions: SessionRecord[]) {
  if (typeof window === 'undefined') return
  try {
    // Keep only last 20 sessions
    const trimmed = sessions.slice(-20)
    localStorage.setItem('neuralhire-sessions', JSON.stringify(trimmed))
  } catch {
    // localStorage might be full
  }
}

export const useUserStore = create<UserState>()(
  (set, get) => ({
    profile: defaultProfile,
    analysis: defaultAnalysis,
    currentSection: 'home',
    sessions: loadSessions(),

    setProfile: (profile) => set((state) => ({ profile: { ...state.profile, ...profile } })),
    setAnalysis: (analysis) => set((state) => ({ analysis: { ...state.analysis, ...analysis } })),
    setCurrentSection: (section) => set({ currentSection: section }),
    resetAnalysis: () => set({ analysis: defaultAnalysis }),

    hasProfile: () => get().profile.isComplete,
    hasAnalysis: () => get().analysis.overallScore !== null,

    // Save current session to history before resetting
    saveCurrentSession: () => {
      const { profile, analysis, sessions } = get()
      if (!profile.isComplete) return // Don't save empty sessions

      const record: SessionRecord = {
        id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        date: new Date().toISOString(),
        profileName: profile.name || 'Unknown',
        profileRole: profile.role || 'Not specified',
        overallScore: analysis.overallScore,
        profile: { ...profile },
        analysis: { ...analysis },
      }

      const updated = [...sessions, record]
      saveSessions(updated)
      set({ sessions: updated })
    },

    // Reset everything for a new user — fresh start
    resetSession: () => {
      const { profile, analysis } = get()
      // Auto-save current session to history if it has data
      if (profile.isComplete) {
        const record: SessionRecord = {
          id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
          date: new Date().toISOString(),
          profileName: profile.name || 'Unknown',
          profileRole: profile.role || 'Not specified',
          overallScore: analysis.overallScore,
          profile: { ...profile },
          analysis: { ...analysis },
        }
        const updated = [...get().sessions, record]
        saveSessions(updated)
        set({ sessions: updated })
      }

      // Reset to clean state
      set({
        profile: defaultProfile,
        analysis: defaultAnalysis,
        currentSection: 'home',
      })
    },

    // Load a past session from history
    loadSession: (id: string) => {
      const session = get().sessions.find(s => s.id === id)
      if (session) {
        set({
          profile: session.profile,
          analysis: session.analysis,
          currentSection: 'digital-profile',
        })
      }
    },

    // Delete a session from history
    deleteSession: (id: string) => {
      const updated = get().sessions.filter(s => s.id !== id)
      saveSessions(updated)
      set({ sessions: updated })
    },
  })
)
