import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

async function getAIResponse(prompt: string, temperature = 0.7): Promise<string> {
  try {
    const zai = await ZAI.create()
    const result = await zai.chat.completions.create({
      messages: [{ role: 'user', content: prompt }],
      temperature,
    })
    return result.choices?.[0]?.message?.content || ''
  } catch (error) {
    console.error('AI SDK error:', error)
    return ''
  }
}

function extractJSON(text: string): Record<string, unknown> | null {
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/)
    return jsonMatch ? JSON.parse(jsonMatch[0]) : null
  } catch {
    return null
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { type, data } = body

    switch (type) {
      case 'video-analysis': {
        // DEPRECATED: Video analysis now goes through /api/analyze-video
        // which actually validates the video and uses VLM for real analysis
        // This route only handles text-based profile analysis as a fallback
        return NextResponse.json({
          success: false,
          error: 'Video analysis now requires actual video upload. Please use the video upload feature.',
        })
      }

      case 'personality-radar': {
        const { profile, analysisData } = data || {}
        if (!profile || !analysisData) {
          return NextResponse.json(
            { success: false, error: 'Profile and analysis data required for personality radar.' },
            { status: 400 }
          )
        }

        const prompt = `You are an AI personality analyst. Based on this person's profile and video analysis data, generate a detailed personality radar.

Profile: ${JSON.stringify(profile)}
Analysis Data: ${JSON.stringify(analysisData)}

Return ONLY valid JSON (no markdown, no code blocks):
{
  "personalityDimensions": {
    "leadership": <number 30-98>,
    "confidence": <number 30-98>,
    "creativity": <number 30-98>,
    "emotionalIntelligence": <number 30-98>,
    "adaptability": <number 30-98>,
    "collaboration": <number 30-98>,
    "pressureHandling": <number 30-98>
  }
}

Base scores on the actual analysis data provided. If confidence was scored low, leadership should reflect that. Be honest and consistent.`

        const text = await getAIResponse(prompt, 0.6)
        let radarData = extractJSON(text)

        if (!radarData?.personalityDimensions) {
          // Instead of fake fallback, return error
          return NextResponse.json({
            success: false,
            error: 'AI personality analysis failed. Please try again.',
          })
        }

        return NextResponse.json({ success: true, radar: radarData })
      }

      case 'career-prediction': {
        const { profile, analysisData } = data || {}
        if (!profile || !analysisData) {
          return NextResponse.json(
            { success: false, error: 'Profile and analysis data required for career predictions.' },
            { status: 400 }
          )
        }

        const prompt = `You are an AI career predictor. Based on this person's profile and analysis, predict career paths.

Profile: ${JSON.stringify(profile)}
Analysis Data: ${JSON.stringify(analysisData)}

Return ONLY valid JSON (no markdown, no code blocks):
{
  "careerPredictions": [
    {"title": "<career title>", "match": <number 40-98>, "description": "<1 sentence>", "strengths": ["<strength1>", "<strength2>", "<strength3>"]},
    {"title": "<career title>", "match": <number 35-95>, "description": "<1 sentence>", "strengths": ["<strength1>", "<strength2>", "<strength3>"]},
    {"title": "<career title>", "match": <number 30-93>, "description": "<1 sentence>", "strengths": ["<strength1>", "<strength2>", "<strength3>"]}
  ]
}

Base predictions on actual analysis scores. If leadership is low, don't recommend leadership roles. Be realistic.`

        const text = await getAIResponse(prompt, 0.7)
        let predictions = extractJSON(text)

        if (!predictions?.careerPredictions) {
          return NextResponse.json({
            success: false,
            error: 'AI career prediction failed. Please try again.',
          })
        }

        return NextResponse.json({ success: true, predictions })
      }

      case 'emotional-timeline': {
        const { profile, interviewMessages } = data || {}
        const userMessages = (interviewMessages || []).filter((m: { role: string }) => m.role === 'user')

        if (userMessages.length === 0) {
          return NextResponse.json({ success: true, timeline: [] })
        }

        const prompt = `You are an AI emotional intelligence analyst. Based on this person's profile and interview responses, generate an emotional timeline.

Profile: ${JSON.stringify(profile || {})}
Interview Responses: ${JSON.stringify(userMessages.map((m: { text: string }) => m.text))}

Return ONLY valid JSON (no markdown, no code blocks):
{
  "timeline": [
    ${userMessages.map((_: unknown, i: number) => `{"phase": "<phase name like Introduction/Experience/Leadership/Problem-Solving/Creativity/Cultural Fit/Closing>", "confidence": <number 30-98>, "engagement": <number 30-98>, "stress": <number 5-60>}`).join(',\n    ')}
  ]
}

Vary scores realistically based on the actual responses. Longer, more detailed answers should show higher engagement. Short or vague answers should show lower confidence. Make it feel genuine.`

        const text = await getAIResponse(prompt, 0.7)
        let timelineData = extractJSON(text)

        if (!timelineData?.timeline || !Array.isArray(timelineData.timeline)) {
          return NextResponse.json({
            success: false,
            error: 'AI emotional timeline generation failed. Please try again.',
          })
        }

        return NextResponse.json({ success: true, timeline: timelineData.timeline })
      }

      case 'interview-analysis': {
        const { profile, messages, currentAnswer } = data || {}
        if (!currentAnswer) {
          return NextResponse.json(
            { success: false, error: 'No answer provided for analysis.' },
            { status: 400 }
          )
        }

        const prompt = `You are an AI interview analyst. Analyze this interview response in context.

Profile: ${JSON.stringify(profile || {})}
Interview Messages So Far: ${JSON.stringify(messages?.slice(-6) || [])}
Current Answer: ${currentAnswer}

Return ONLY valid JSON (no markdown, no code blocks):
{
  "confidence": <number 20-98>,
  "communication": <number 20-98>,
  "hesitation": <number 5-60>,
  "sentiment": "<Positive|Analytical|Engaged|Cautious|Nervous>",
  "nextQuestion": "<a relevant follow-up interview question>"
}

Base confidence on how assured the response sounds. Short or uncertain answers = lower confidence. Detailed, structured answers = higher confidence. Be honest, not flattering.`

        const text = await getAIResponse(prompt, 0.6)
        let interviewAnalysis = extractJSON(text)

        if (!interviewAnalysis || typeof interviewAnalysis.confidence !== 'number') {
          return NextResponse.json({
            success: false,
            error: 'AI interview analysis failed. Please try again.',
          })
        }

        return NextResponse.json({ success: true, interview: interviewAnalysis })
      }

      default:
        return NextResponse.json(
          { success: false, error: 'Unknown analysis type' },
          { status: 400 }
        )
    }
  } catch (error) {
    console.error('Analysis API error:', error)
    return NextResponse.json(
      { success: false, error: 'Analysis request failed' },
      { status: 500 }
    )
  }
}
